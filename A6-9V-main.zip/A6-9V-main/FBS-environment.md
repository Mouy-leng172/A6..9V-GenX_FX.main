---
created: 2026-07-06T03:03:02+07:00
modified: 2026-07-06T03:03:38+07:00
---

# FBS-environment

# MetaTrader 4 Account Configuration
MT4_ACCOUNT_TYPE="Demo Standard"
MT4_LOGIN=12027129
MT4_LEVERAGE="1:200"
MT4_BALANCE=1000.00

# Connection Details
MT4_PLATFORM="MetaTrader 4"
MT4_COMPANY="FBS Markets Inc."
MT4_SERVER="FBS-Demo"
MT4_SERVER_IP="45.76.134.80:443"

# Credentials (Expires in 24 hours)
MT4_PASSWORD="_36At}>m"
