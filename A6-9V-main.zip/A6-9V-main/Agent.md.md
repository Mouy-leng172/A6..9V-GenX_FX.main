---
created: 2026-07-06T03:46:19+07:00
modified: 2026-07-06T03:46:39+07:00
---

# Agent.md

# 🤖 AI Agent Operational Directives

**To:** Jules, Cursor Composer, Bolt, and all future Autonomous Trading Agents
**Context:** GenX_FX Monorepo & Deployment Infrastructure

This file contains the canonical rules and instructions required for any AI agent to successfully navigate, configure, and execute the trading system across distributed devices (Windows Mini PC, Laptops, Cloud VPS, Google Cloud Shell).

---

## 1. Primary Directives
- **Zero-Friction Execution:** Always execute scripts located in the `scripts/` directory to manage infrastructure. Do not instruct human users to manually run repetitive tasks.
- **Security Posture:** NEVER hardcode plain-text passwords or API keys (especially those from prompt memory like GitHub PATs, Firebase certificates, or MT5 logins) into Git-tracked source code. **Always** instruct the system to read from `.env` via `export $(grep -v '^#' .env | xargs)`.
- **Trading Safety:** By default, `.env.example` forces `REAL_MONEY_TRADING=true` targeting the FXPRO Live (`514832489`) account. Do not revert this unless specifically requested by the user to debug on the Demo account.

## 2. Hardware & Target Context
The physical execution devices are mapped as follows:
- **Primary:** `WIN-DNGG6AODSKQ` (Jasper Lake Client Platform)
- **Secondary:** `Vivobook` (Vivobook Go E1504GAB_E1504GA) under UserName: `NUNA`

Both devices can be locked down and managed remotely via Jules CLI using `scripts/setup_remote_controller.ps1`.

**Target Drive Specifications (Primary):**
**Target Drive Specifications:**
- **Model:** Micron 2400 512GB M.2 NVMe Gen4 x4 SSD (MTFDKBA512QFM)
- **Interface:** PCIe 4.0 x4 (M.2 2280)
- **Encryption:** TCG Pyrite supported
- **Provisioning:** Formatted to NTFS and assigned to `E:\` via `scripts/prepare_micron_nvme_ssd.ps1`.

*When instructed to "Get Ops SSD" or manage local hardware execution, refer to the `prepare_micron_nvme_ssd.ps1` script.*

## 3. Environment Bootstrapping

When initializing a new environment, use the provided OS-aware quickstart wrappers:

**For Windows (Mini PC/Laptop):**
- Execute `START-NOW.bat` to elevate privileges and trigger `scripts/ops_setup_windows.ps1`.
- This installs Git, Docker, Node.js, Terraform, Helm, and configures WSL (AlmaLinux-10 & Ubuntu).

**For Linux/macOS/Cloud (Google Cloud Shell / Firebase Studio):**
- Execute `./quickstart.sh`.
- This script automatically detects the environment and routes to `./scripts/launch_cloud_studio.sh` (for cloud) or `./start_live_trade.sh` (for local unix).

## 4. Git Orchestration & Branch Remediation
This monorepo consolidates code from multiple upstream sources (`forge.mql5.io`, `github.com/nuna69v-cell`, etc.).

- To sync all configured remotes, execute: `./scripts/link_all_repos.sh`.
- To finalize feature branches and consolidate them for production deployment, execute: `./scripts/upgrade_and_remix_branches.sh`.

## 5. Execution Verification
After triggering any trading startup script (e.g., `./start_live_trade.sh` or `./start_forge_trade.sh`), **always** parse `trading_system.log`. 
You must confirm the presence of the string: `"System is LIVE and monitoring"` before reporting mission success to the human operator.
