---
created: 2026-07-06T03:17:49+07:00
modified: 2026-07-06T03:18:08+07:00
---

# BitLocker Recovery Keys

# Microsoft Account | BitLocker Recovery Keys

This document stores encrypted drive recovery key metadata for devices linked to the Microsoft account **lengkundee01@outlook.com**.

| Device Name       | Key ID                                   | Recovery Key (partial)                     | Drive | Key Upload Date (UTC)        |
|--------------------|------------------------------------------|--------------------------------------------|--------|------------------------------|
| DESKTOP-4U28ARV    | 92031423                                 | 266189-175241-504845-...-284152            | FDV    | 2025-12-06 14:56:33          |
| DESKTOP-4U28ARV    | 3EDFEB79                                 | 015642-040645-460108-...-466037            | OSV    | 2025-12-06 14:56:30          |
| LAPTOP-BU7V0BMV    | 72515CC3                                 | 067232-081653-648043-...-249854            | FDV    | 2025-10-18 14:08:21          |
| LAPTOP-BU7V0BMV    | 6FF65E1A                                 | 546568-333839-378774-...-378917            | OSV    | 2025-10-18 14:08:19          |
| WIN-DNGG6AODSKQ    | 929D6F32-CB26-4351-8478-3DFA9A2206AF     | 490468-677644-294195-...-227931            | OSV    | 2026-04-20 06:41:42          |
| WIN-DNGG6AODSKQ    | EC1E89A0-EAFB-4BB7-B86F-99AA56F493CD     | 055605-528330-415261-...-048785            | RDV    | 2026-05-23 14:37:59          |

> ⚠️ **Security Note:** Do not commit full recovery keys to public repositories. Store only partial keys or encrypted versions.  
> For private repositories, ensure `.gitignore` excludes sensitive files or use GitHub Secrets for secure storage.

---

### 💡 Recommended GitHub workflow
1. Create a new private repo (e.g., `Device-Recovery-Keys`).
2. Add this file under `/docs/security/BitLocker-Recovery-Keys.md`.
3. Commit with message:  
   `chore(security): add BitLocker recovery key metadata`
4. Push to GitHub using your CLI or GitHub Desktop.

---

Would you like me to format this as a **JSON** or **YAML** file instead (for automation or backup scripts)?
