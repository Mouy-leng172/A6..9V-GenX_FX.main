---
created: 2026-07-06T04:26:27+07:00
modified: 2026-07-06T04:27:03+07:00
---

# test_trading_engine

import pytest
import os
from unittest.mock import patch, MagicMock
from trading_engine import TradingNode, AIEngine, setup_trading_nodes

def test_trading_node_initialization():
    node = TradingNode("123", "TestServer", "Demo", "TestVPS", ["SYM1"], "password123")
    assert node.node_id == "123"
    assert node.server == "TestServer"
    assert node.account_type == "Demo"
    assert node.vps_location == "TestVPS"
    assert node.symbols == ["SYM1"]
    assert node.password == "password123"

def test_ai_engine_initialization():
    engine = AIEngine()
    assert "JULES API" in engine.apis
    assert "Firebase Gemini" in engine.apis
    assert "Cursor API" in engine.apis

@patch('trading_engine.logger')
def test_execute_trade(mock_logger):
    engine = AIEngine()
    node = TradingNode("123", "TestServer", "Demo", "TestVPS", ["SYM1"])
    engine.execute_trade(node, "SYM1", "BUY", 1.0)
    mock_logger.info.assert_called_with("[AI SIGNAL] Executing BUY on SYM1 | Volume: 1.0 | Node: 123")
    
@patch('trading_engine.TradingNode')
@patch('trading_engine.AIEngine')
def test_setup_trading_nodes_demo_only(mock_ai_engine, mock_trading_node):
    with patch.dict(os.environ, {
        "FXPRO_DEMO_PASSWORD": "Leng3Una@Horel",
        "FXPRO_LIVE_PASSWORD": "Leng3Una@Horel",
        "Real_money_trade": "false"
    }):
        setup_trading_nodes()
        
        # Check if Demo Node was created
        mock_trading_node.assert_any_call(
            node_id="591360974",
            server="FxPro-MT5 Demo",
            account_type="Demo",
            vps_location="VPS Amsterdam 16",
            symbols=["XAUUSD", "BTCXAU", "BTCUSD"],
            password="Leng3Una@Horel"
        )
        
        # Check that Live Node was NOT created
        for call in mock_trading_node.call_args_list:
            assert call.kwargs.get("node_id") != "514832489"

@patch('trading_engine.TradingNode')
@patch('trading_engine.AIEngine')
def test_setup_trading_nodes_live(mock_ai_engine, mock_trading_node):
    with patch.dict(os.environ, {
        "FXPRO_DEMO_PASSWORD": "Leng3Una@Horel",
        "FXPRO_LIVE_PASSWORD": "Leng3Una@Horel",
        "Real_money_trade": "true"
    }):
        setup_trading_nodes()
        
        # Check if Demo Node was created
        mock_trading_node.assert_any_call(
            node_id="591360974",
            server="FxPro-MT5 Demo",
            account_type="Demo",
            vps_location="VPS Amsterdam 16",
            symbols=["XAUUSD", "BTCXAU", "BTCUSD"],
            password="Leng3Una@Horel"
        )
        
        # Check if Live Node was created
        mock_trading_node.assert_any_call(
            node_id="514832489",
            server="FxPro-MT5",
            account_type="LIVE Standard",
            vps_location="VPS London LD4 03",
            symbols=["XAUUSD (GOLD)"],
            password="Leng3Una@Horel"
        )
