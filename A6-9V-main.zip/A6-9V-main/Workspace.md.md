---
created: 2026-07-06T02:56:47+07:00
modified: 2026-07-06T02:57:06+07:00
---

# Workspace.md

#!/usr/bin/env python3
"""
Workspace Domain Startup Script
Automated startup for the enhanced domain controller with secret management
"""

import os
import sys
import time
import logging
import subprocess
from pathlib import Path
from typing import Optional

from google_secret_manager import GoogleSecretManagerClient
from enhanced_domain_controller import EnhancedDomainController

class WorkspaceDomainManager:
    def __init__(self):
        self.setup_logging()
        self.project_id = self.detect_project_id()
        self.secret_manager = None
        self.domain_controller = None
    
    def setup_logging(self):
        """Setup logging for the workspace manager"""
        log_dir = Path(__file__).parent / 'logs'
        log_dir.mkdir(exist_ok=True)
        
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_dir / 'workspace_domain.log'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)
    
    def detect_project_id(self) -> Optional[str]:
        """Detect Google Cloud project ID from various sources"""
        # Try environment variable
        project_id = os.getenv('GOOGLE_CLOUD_PROJECT')
        if project_id:
            return project_id
        
        # Try gcloud config
        try:
            result = subprocess.run(['gcloud', 'config', 'get-value', 'project'], 
                                  capture_output=True, text=True, timeout=10)
            if result.returncode == 0 and result.stdout.strip():
                return result.stdout.strip()
        except Exception:
            pass
        
        # Default fallback
        return 'fortress-notes-omrjz'
    
    def check_prerequisites(self) -> bool:
        """Check if all prerequisites are met"""
        self.logger.info("Checking prerequisites...")
        
        # Check Python dependencies
        required_packages = [
            'google-cloud-secret-manager',
            'flask',
            'flask-socketio',
            'python-dotenv'
        ]
        
        missing_packages = []
        for package in required_packages:
            try:
                __import__(package.replace('-', '_'))
            except ImportError:
                missing_packages.append(package)
        
        if missing_packages:
            self.logger.error(f"Missing packages: {missing_packages}")
            self.logger.info("Run: pip install -r requirements.txt")
            return False
        
        # Check Google Cloud authentication
        try:
            subprocess.run(['gcloud', 'auth', 'application-default', 'print-access-token'], 
                          capture_output=True, check=True, timeout=10)
            self.logger.info("✓ Google Cloud authentication is working")
        except Exception as e:
            self.logger.warning(f"Google Cloud authentication issue: {e}")
            self.logger.info("Run: gcloud auth application-default login")
            return False
        
        return True
    
    def initialize_secret_manager(self) -> bool:
        """Initialize Google Secret Manager client"""
        try:
            self.secret_manager = GoogleSecretManagerClient(project_id=self.project_id)
            self.logger.info("✓ Google Secret Manager initialized")
            return True
        except Exception as e:
            self.logger.error(f"Failed to initialize Secret Manager: {e}")
            return False
    
    def create_local_env(self):
        """Create local .env file from Secret Manager"""
        if not self.secret_manager:
            return
        
        try:
            env_path = Path(__file__).parent / '.env'
            self.secret_manager.create_env_file(env_path)
            self.logger.info(f"✓ Created local .env file at {env_path}")
        except Exception as e:
            self.logger.warning(f"Could not create local .env file: {e}")
    
    def start_domain_controller(self, debug: bool = False, port: int = 5000):
        """Start the enhanced domain controller"""
        try:
            self.logger.info("Starting Enhanced Domain Controller...")
            self.domain_controller = EnhancedDomainController(project_id=self.project_id)
            self.domain_controller.config['web']['port'] = port
            self.domain_controller.run(debug=debug)
        except Exception as e:
            self.logger.error(f"Failed to start domain controller: {e}")
            raise
    
    def run_health_check(self) -> bool:
        """Run health check on all systems"""
        self.logger.info("Running health check...")
        
        checks = {
            'secret_manager': self.secret_manager is not None,
            'project_id': self.project_id is not None,
            'workspace_directory': Path(__file__).parent.exists()
        }
        
        if self.secret_manager:
            try:
                # Test secret retrieval
                test_secrets = self.secret_manager.get_api_keys()
                checks['secret_retrieval'] = len(test_secrets) > 0
            except Exception:
                checks['secret_retrieval'] = False
        
        # Log results
        for check, status in checks.items():
            status_text = "✓" if status else "✗"
            self.logger.info(f"{status_text} {check}: {status}")
        
        return all(checks.values())
    
    def run(self, debug: bool = False, port: int = 5000, skip_checks: bool = False):
        """Main run method"""
        self.logger.info("=== Workspace Domain Manager Starting ===")
        
        if not skip_checks:
            if not self.check_prerequisites():
                self.logger.error("Prerequisites not met. Exiting.")
                return False
        
        # Initialize Secret Manager
        if not self.initialize_secret_manager():
            self.logger.warning("Secret Manager initialization failed. Continuing with local env...")
        
        # Create local env backup
        self.create_local_env()
        
        # Run health check
        health_ok = self.run_health_check()
        if not health_ok and not skip_checks:
            self.logger.warning("Health check failed. Continuing anyway...")
        
        # Start domain controller
        try:
            self.start_domain_controller(debug=debug, port=port)
        except KeyboardInterrupt:
            self.logger.info("Received shutdown signal")
        except Exception as e:
            self.logger.error(f"Domain controller failed: {e}")
            return False
        
        self.logger.info("=== Workspace Domain Manager Stopped ===")
        return True


def main():
    """Main CLI function"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Workspace Domain Manager')
    parser.add_argument('--project-id', help='Google Cloud project ID')
    parser.add_argument('--debug', action='store_true', help='Run in debug mode')
    parser.add_argument('--port', type=int, default=5000, help='Web interface port')
    parser.add_argument('--skip-checks', action='store_true', help='Skip prerequisite checks')
    parser.add_argument('--health-check-only', action='store_true', help='Run health check only')
    
    args = parser.parse_args()
    
    manager = WorkspaceDomainManager()
    
    if args.project_id:
        manager.project_id = args.project_id
    
    if args.health_check_only:
        manager.initialize_secret_manager()
        success = manager.run_health_check()
        return 0 if success else 1
    
    try:
        success = manager.run(
            debug=args.debug,
            port=args.port,
            skip_checks=args.skip_checks
        )
        return 0 if success else 1
    
    except Exception as e:
        print(f"Error: {e}")
        return 1


if __name__ == "__main__":
    exit(main())
