---
created: 2026-07-06T03:37:01+07:00
modified: 2026-07-06T03:38:11+07:00
---

# Ubuntu​​-AMD.md

https://releases.ubuntu.com/26.04/ubuntu-26.04-desktop-amd64.iso
