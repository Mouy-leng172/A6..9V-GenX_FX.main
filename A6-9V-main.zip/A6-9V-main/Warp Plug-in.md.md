---
created: 2026-07-06T03:34:47+07:00
modified: 2026-07-06T03:35:07+07:00
---

# Warp Plug-in.md

<a href="https://www.warp.dev">
    <img width="1448" alt="Warp Agentic Development Products" src="https://github.com/user-attachments/assets/f783af23-3531-40cd-baf2-e6f5c696bcb3" />
</a>

<p align="center">
  <a href="https://www.warp.dev">Website</a>
  ·
  <a href="https://www.warp.dev/code">Code</a>
  ·
  <a href="https://www.warp.dev/agents">Agents</a>
  ·
  <a href="https://www.warp.dev/terminal">Terminal</a>
  ·
  <a href="https://www.warp.dev/drive">Drive</a>
  ·
  <a href="https://docs.warp.dev">Docs</a>
  ·
  <a href="https://www.warp.dev/blog/how-warp-works">How Warp Works</a>
</p>

## About Warp

We built Warp to solve two problems we kept hitting as a team writing software: terminals haven't kept up with how developers work today, and agentic development tools don't scale beyond your laptop.

**Warp is a modern terminal built for coding with agents.** Warp brings the terminal into the 21st century with modern UI and code editing features. Use Warp’s SOTA built-in agent Oz, or run CLI coding agents like Claude Code, Codex, or Gemini CLI.

**Oz is an orchestration platform for cloud agents.** Spin up unlimited parallel coding agents that are programmable, auditable, and fully steerable. Automate repetitive tasks, build on agents, and run them in parallel in the cloud. [Create an agent →](http://warp.dev/oz) 

## Getting started

[Download](https://www.warp.dev/download) the Warp app and [read our docs](https://docs.warp.dev/) if you're just getting started with Warp.

You can also take a look at the open-source [oz-skills](https://github.com/warpdotdev/oz-skills) and [oz-dev-environments](https://github.com/warpdotdev/oz-dev-environments) that you can use via [cloud agents](https://docs.warp.dev/agent-platform/cloud-agents/cloud-agents-overview).

## Changelog and Releases

We try to release an update weekly, typically on Thursdays. Read our [changelog (release notes).](https://docs.warp.dev/getting-started/changelog)

## Issues, Bugs, and Feature Requests

Please [search](https://github.com/warpdotdev/warp/issues?q=is%3Aissue+is%3Aopen+sort%3Areactions-%2B1-desc) through our existing issues for your bug (including workarounds) or feature request.

If you can't find a solution above, please file issue requests [in this repo!](https://github.com/warpdotdev/warp/issues/new/choose)
We kindly ask that you please use our issue templates to make the issues easier to track for our team.

## Open-Source & Contributing

Warp's client codebase is now open-source and lives in [`warpdotdev/warp`](https://github.com/warpdotdev/warp).

We welcome community contributions — see [CONTRIBUTING.md](https://github.com/warpdotdev/warp/blob/main/CONTRIBUTING.md) for the full flow, including how to build the repo locally and our `ready-to-spec` / `ready-to-implement` labels for picking up work.

For a live overview of issue triage, agent activity, and what's ready to pick up, check out [build.warp.dev](https://build.warp.dev) — the community dashboard for contributions to the open-source Warp repo.

We also open-source our extension points as we go. The community has already been [contributing new themes](https://github.com/warpdotdev/themes), and our [Workflows repository](https://github.com/warpdotdev/workflows) is open for sharing and collaborating on useful command patterns.


## Support and Questions

1. See our [docs](https://docs.warp.dev/) for a comprehensive guide to Warp's features.
2. Join our [Slack Community](https://go.warp.dev/join-preview) to connect with other users and get help from the Warp team.
3. Try our [Preview build](https://www.warp.dev/download-preview) to test Warp's newest and latest experimental features.

For anything else, please don't hesitate to reach out via email at hello at warpdotdev

## Community Guidelines

At a high level, we ask everyone to be respectful and empathetic. We follow the [GitHub Community Guidelines](https://docs.github.com/en/github/site-policy/github-community-guidelines):

* Be welcoming and open-minded
* Respect each other
* Communicate with empathy
* Be clear and stay on topic

## Open Source Dependencies

We'd like to call out a few of the [open source dependencies](https://docs.warp.dev/help/licenses) that have helped Warp to get off the ground:

* [Tokio](https://github.com/tokio-rs/tokio)
* [NuShell](https://github.com/nushell/nushell)
* [Fig Completion Specs](https://github.com/withfig/autocomplete)
* [Warp Server Framework](https://github.com/seanmonstar/warp)
* [Alacritty](https://github.com/alacritty/alacritty)
* [Hyper HTTP library](https://github.com/hyperium/hyper)
* [FontKit](https://github.com/servo/font-kit)
* [Core-foundation](https://github.com/servo/core-foundation-rs)
* [Smol](https://github.com/smol-rs/smol)
