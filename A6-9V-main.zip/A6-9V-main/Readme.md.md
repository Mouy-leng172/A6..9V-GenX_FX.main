---
created: 2026-07-06T03:10:39+07:00
modified: 2026-07-06T03:10:52+07:00
---

# Readme.md

# Workspace Domain Management

This workspace provides Google Secret Manager integration and enhanced domain controller functionality for managing your I: drive workspace.

## Quick Start

1. **Install dependencies:**

   ```bash
   pip install -r requirements.txt
   ```

2. **Setup Google Cloud authentication:**

   ```bash
   gcloud auth application-default login
   gcloud config set project fortress-notes-omrjz
   ```

3. **Run the automated setup:**

   ```bash
   setup_workspace_domain.bat
   ```

4. **Start the workspace domain:**

   ```bash
   python workspace_domain_manager.py
   ```

5. **Access the dashboard:**
   - Open <http://localhost:5000> in your browser

## Components

### Google Secret Manager Client (`google_secret_manager.py`)

- Retrieves API keys and secrets from Google Cloud Secret Manager
- Creates local .env files for backup
- Supports batch secret retrieval
- CLI interface for individual secret access

**Usage:**

```bash
# Get all API keys
python google_secret_manager.py --list-api-keys

# Get specific secret
python google_secret_manager.py --secret-name openai-api-key

# Create .env file
python google_secret_manager.py --create-env .env

# Create JSON config
python google_secret_manager.py --create-json secrets.json
```

### Enhanced Domain Controller (`enhanced_domain_controller.py`)

- Web-based dashboard for drive management
- Real-time drive scanning and monitoring
- Secret Manager integration
- REST API for drive status
- WebSocket support for real-time updates

**Features:**

- Drive health monitoring
- Secret status reporting
- Web dashboard at <http://localhost:5000>
- API endpoints for integration

### Workspace Domain Manager (`workspace_domain_manager.py`)

- Automated startup and health checking
- Prerequisites validation
- Integrated secret and domain management
- Comprehensive logging

**Usage:**

```bash
# Start with default settings
python workspace_domain_manager.py

# Start in debug mode
python workspace_domain_manager.py --debug

# Use different port
python workspace_domain_manager.py --port 8080

# Health check only
python workspace_domain_manager.py --health-check-only

# Skip prerequisite checks
python workspace_domain_manager.py --skip-checks
```

## Configuration

### Environment Variables

Create a `.env` file or use Google Secret Manager with these keys:

```env
GOOGLE_CLOUD_PROJECT=fortress-notes-omrjz
OPENAI_API_KEY=your_openai_key
CLAUDE_API_KEY=your_claude_key
GEMINI_API_KEY=your_gemini_key
GITHUB_TOKEN=your_github_token
FIREBASE_API_KEY=your_firebase_key
```

### Drive Configuration (`config/drives.json`)

Configure monitored drives and system settings:

```json
{
  "drives": {
    "I": {
      "path": "I:\\",
      "type": "backup",
      "enabled": true,
      "description": "Main backup drive"
    }
  },
  "web": {
    "enabled": true,
    "port": 5000,
    "host": "0.0.0.0"
  }
}
```

## API Endpoints

### Drive Management

- `GET /` - Dashboard web interface
- `GET /api/drives` - Get all drive status
- `GET /api/config` - Get configuration (sanitized)
- `GET /api/secrets/status` - Get secret manager status
- `POST /api/refresh-secrets` - Refresh secrets from Secret Manager

### WebSocket Events

- `connect` - Client connection
- `scan_drives` - Trigger drive scan
- `drives_updated` - Receive drive updates

## Security

- Secrets are never exposed in API responses
- Local .env files are created as backup
- Google Cloud authentication required
- Dashboard runs on localhost by default

## Logging

Logs are written to the `logs/` directory:

- `workspace_domain.log` - Main application log
- `secret_manager.log` - Secret Manager operations
- `domain_controller.log` - Domain controller events

## Troubleshooting

### Authentication Issues

```bash
# Re-authenticate with Google Cloud
gcloud auth application-default login

# Check current authentication
gcloud auth application-default print-access-token
```

### Missing Dependencies

```bash
# Install all requirements
pip install -r requirements.txt

# Install Google Cloud SDK
# Download from: https://cloud.google.com/sdk/docs/install
```

### Port Conflicts

```bash
# Use different port
python workspace_domain_manager.py --port 8080
```

### Secret Manager Access

Ensure your Google Cloud account has these IAM roles:

- Secret Manager Secret Accessor
- Secret Manager Viewer

## Integration with Existing Domain Controller

This workspace integrates with your existing domain controller setup found in:

- `i:\Adata_USB_Backup_20251026_142937\domain-controller\`

The enhanced version extends the original functionality while maintaining compatibility.

## Next Steps

1. **Configure secrets in Google Secret Manager:**
   - Go to Google Cloud Console > Secret Manager
   - Create secrets with names like `openai-api-key`, `github-token`, etc.

2. **Set up automatic secret rotation:**
   - Configure secret versions in Google Secret Manager
   - Use the refresh API endpoint for periodic updates

3. **Extend drive monitoring:**
   - Add more drives to `config/drives.json`
   - Configure custom scan intervals
   - Set up alerting for drive health issues

4. **Custom integrations:**
   - Use the REST API for external integrations
   - Extend WebSocket events for real-time updates
   - Add custom secret retrieval logic
