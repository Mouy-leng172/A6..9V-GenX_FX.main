---
created: 2026-07-06T03:05:48+07:00
modified: 2026-07-06T03:06:23+07:00
---

# Fxpro-metatrader5

Server: FxPro.com-Demo06
Company: FxPro Markets Ltd.
Login: 60391636
Password: czcu4zl
Investor: kxh1tib
MetaQuotesID : 2E5DB4C5
Broker Information

Registration Number: 1500543 (IBC)
Company : FxPro Markets Ltd.
Registration Address: BankPro House, Office 2, Western Road, Lyford Cay, New Providence, 
Non-regulated : Bahamas
Ac : Status
Website: www.fxpro.com
Generic Email: info@fxpro.com        
Abuse Reporting Email: info@fxpro.com
Phone: +1 2426032222
