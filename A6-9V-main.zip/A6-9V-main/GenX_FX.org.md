---
created: 2026-07-06T03:54:15+07:00
modified: 2026-07-06T03:54:33+07:00
---

# GenX_FX.org

‎Here is a full review of the genxfx_org.crt X.509 TLS certificate:
‎
‎🔐 Certificate Review — genxfx_org.crt
‎
‎📋 General Information
‎
‎| Field | Value |
‎|---|---|
‎| File | Copy of genxfx_org.crt |
‎| File Size | 2,312 bytes |
‎| Format | PEM (Base64-encoded X.509 v3) |
‎| Certificate Type | TLS Web Server (DV — Domain Validated) |
‎
‎🌐 Subject & Issuer
‎
‎| Field | Value |
‎|---|---|
‎| Subject (CN) | genxfx.org |
‎| Subject Alt Names (SAN) | genxfx.org, www.genxfx.org |
‎| Issuer | Sectigo Limited — Sectigo Public Server Authentication CA DV R36 |
‎| Issuer Country | GB (United Kingdom) |
‎
‎📅 Validity
‎
‎| Field | Value |
‎|---|---|
‎| Not Before | September 19, 2025 00:00:00 UTC |
‎| Not After | September 19, 2026 23:59:59 UTC |
‎| Status | ✅ Currently VALID |
‎| Days Remaining | 198 days |
‎
‎🔑 Key & Signature Details
‎
‎| Field | Value |
‎|---|---|
‎| Public Key Algorithm | RSA |
‎| Key Size | 2048-bit ⚠️ (see note below) |
‎| Signature Algorithm | sha256WithRSAEncryption ✅ |
‎| Serial Number | 9142C346C09B0F283178083E4DB05176 |
‎
‎🖊️ Fingerprints
‎
‎| Algorithm | Fingerprint |
‎|---|---|
‎| SHA-256 | 76:75:C4:F2:EB:72:51:C2:63:C1:83:EC:ED:CD:53:85:25:E7:70:18:A1:93:28:7B:39:D7:92:E1:8B:E6:0C:8D |
‎| SHA-1 | 5A:4E:F6:41:39:3E:C7:30:65:9F:C2:FF:D8:3B:40:0F:01:AC:94:E7 |
‎
‎🛡️ X.509v3 Extensions
‎
‎| Extension | Value |
‎|---|---|
‎| Key Usage | Digital Signature, Key Encipherment (critical) |
‎| Extended Key Usage | TLS Web Server Auth, TLS Web Client Auth ✅ |
‎| Basic Constraints | CA: FALSE ✅ (not a CA cert) |
‎| OCSP Responder | http://ocsp.sectigo.com |
‎| CA Issuers URL | http://crt.sectigo.com/SectigoPublicServerAuthenticationCADVR36.crt |
‎| CT Logs (SCTs) | 3 Signed Certificate Timestamps ✅ (full CT compliance) |
‎
‎✅ Assessment & Observations
‎
‎1. Valid & Active — The certificate is currently valid with ~198 days of life remaining (expires Sep 19, 2026).
‎2. Issued by Sectigo (trusted CA) — Sectigo is a widely trusted public CA, so this certificate will be accepted by all major browsers and operating systems.
‎3. Correct SAN coverage — Both genxfx.org and www.genxfx.org are covered, which is correct practice.
‎4. CT Compliant — Three SCT (Signed Certificate Timestamp) records are embedded, satisfying Chrome's Certificate Transparency requirements.
‎5. Domain Validation (DV) only — This is a basic DV certificate. If the site handles sensitive transactions, an OV (Organization Validated) or EV (Extended Validation) certificate could be considered for added trust indicators.
‎6. ⚠️ 2048-bit RSA key — This is acceptable today but considered the minimum. Upgrading to 4096-bit RSA or switching to ECDSA P-256/P-384 at next renewal would provide better performance and forward-looking security.
‎7. ✅ SHA-256 signature — Modern, secure hashing algorithm. No issues here.
‎
‎📌 Recommendations
‎
‎- Renewal reminder: Set a calendar alert for ~August 2026 (30 days before expiry).
‎- Key upgrade: At renewal, consider requesting an ECDSA P-256 or P-384 key for better performance and stronger security.
‎- Keep the private key secure: Ensure the corresponding private key is stored safely and never shared alongside this certificate file.
