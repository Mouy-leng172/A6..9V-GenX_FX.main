---
created: 2026-07-06T02:56:16+07:00
modified: 2026-07-06T02:56:46+07:00
---

# Readm.md

# BluDimension Backup
# BluDimension Backup

USB Drive Backup Repository - Prevents data loss and wrong setup

## 📦 Contents

This repository contains a complete backup of the I: drive (USB) including:

- **Development Tools**: All development tools and configurations
- **Projects**: Active and archived projects
- **Backups**: System and project backups
- **Configurations**: System and application configurations
- **Scripts**: Automation and utility scripts

## 🎯 Purpose

- **Data Protection**: Prevent loss of important files and configurations
- **Setup Recovery**: Quick recovery from wrong setups or system failures
- **Version Control**: Track changes and maintain history
- **Portability**: Access your workspace from anywhere

## 📁 Structure

```
I:/
├── Backups/              # Consolidated backups
├── Development/          # Development tools and projects
├── domain-controller/    # Active domain controller project
│   ├── config/           # Domain and system configuration
│   │   ├── domain_config.json      # Namecheap domain configuration
│   │   └── credentials/            # Secure credentials storage
│   ├── security/ssl/     # SSL certificates and keys
│   ├── scripts/          # Domain management scripts
│   └── reports/          # Domain status reports
└── [Other directories]
```

## 🔐 Security

- Private repository - only authorized access
- Sensitive files excluded via .gitignore
- Credentials stored securely (not in repo)

## 🚀 Usage

### Clone Repository
```bash
git clone https://github.com/A6_9V/BluDimention-Backoff.git
```

### Update Backup
```bash
cd I:\
git add .
git commit -m "Backup: $(date)"
git push origin main
```

### Restore
```bash
git clone https://github.com/A6_9V/BluDimention-Backoff.git I:\
```

## 📝 Notes

- Regular backups recommended
- Review .gitignore before committing
- Large files may need Git LFS

## 👥 Organization

- **Organization**: A6_9V
- **Owner**: mouy-leng
- **Repository**: BluDimention-Backoff

---

**Last Updated**: Auto-generated

## ⚙️ MT5 Log Analysis (BTC/XAU)

Use the MT5 log analyzer to review BTC and XAU trading activity:

```bash
cd I:\domain-controller
python scripts\analyze_mt5_logs.py ^
  --log-dir "C:\Users\lengk\AppData\Roaming\MetaQuotes\Terminal\D0E8209F77C8CF37AD8BF550E51FF075\MQL5\Logs" ^
  --output I:\analysis\mt5_log_summary.json
```

This command scans MT5 logs, extracts BTC/XAU trades, warnings, and errors, and saves a summary to `analysis\mt5_log_summary.json`.

## 🌐 Domain Management (Namecheap)

### Domain Control

The domain controller includes comprehensive domain, SSL, and hosting management:

- **Domain Configuration:** `I:\domain-controller\config\domain_config.json`
- **Domain Control Document:** `I:\domain-controller\DOMAIN_SSL_HOSTING_CONTROL.md`
- **Organization Guide:** `I:\domain-controller\DOMAIN_ORGANIZATION.md`

### Check Domain Information

```powershell
cd I:\domain-controller
.\scripts\get_domain_info.ps1 -Domains example.com
```

### Namecheap Account

- **Username:** LengNU
- **Email:** keamouyleng369@gmail.com
- **Login:** https://www.namecheap.com/myaccount/login/

For account recovery and domain information, see:
- `I:\domain-controller\DOMAIN_SSL_HOSTING_CONTROL.md`
- `I:\Development\AIxML_Autonomous_JET\configs\namecheap_account_info.md`

---

USB Drive Backup Repository - Prevents data loss and wrong setup

## 📦 Contents

This repository contains a complete backup of the I: drive (USB) including:

- **Development Tools**: All development tools and configurations
- **Projects**: Active and archived projects
- **Backups**: System and project backups
- **Configurations**: System and application configurations
- **Scripts**: Automation and utility scripts

## 🎯 Purpose

- **Data Protection**: Prevent loss of important files and configurations
- **Setup Recovery**: Quick recovery from wrong setups or system failures
- **Version Control**: Track changes and maintain history
- **Portability**: Access your workspace from anywhere

## 📁 Structure

```
I:/
├── Backups/              # Consolidated backups
├── Development/          # Development tools and projects
├── domain-controller/    # Active domain controller project
│   ├── config/           # Domain and system configuration
│   │   ├── domain_config.json      # Namecheap domain configuration
│   │   └── credentials/            # Secure credentials storage
│   ├── security/ssl/     # SSL certificates and keys
│   ├── scripts/          # Domain management scripts
│   └── reports/          # Domain status reports
└── [Other directories]
```

## 🔐 Security

- Private repository - only authorized access
- Sensitive files excluded via .gitignore
- Credentials stored securely (not in repo)

## 🚀 Usage

### Clone Repository
```bash
git clone https://github.com/A6_9V/BluDimention-Backoff.git
```

### Update Backup
```bash
cd I:\
git add .
git commit -m "Backup: $(date)"
git push origin main
```

### Restore
```bash
git clone https://github.com/A6_9V/BluDimention-Backoff.git I:\
```

## 📝 Notes

- Regular backups recommended
- Review .gitignore before committing
- Large files may need Git LFS

## 👥 Organization

- **Organization**: A6_9V
- **Owner**: mouy-leng
- **Repository**: BluDimention-Backoff

---

**Last Updated**: Auto-generated
